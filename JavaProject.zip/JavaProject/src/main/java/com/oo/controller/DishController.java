package com.oo.controller;

import com.oo.constant.ResultCodeConstant;
import com.oo.pojo.domain.DishDO;
import com.oo.pojo.dto.CreateGroup;
import com.oo.pojo.dto.DishDTO;
import com.oo.pojo.dto.RestResult;
import com.oo.pojo.dto.UpdateGroup;
import com.oo.pojo.query.DishQuery;
import com.oo.pojo.vo.PageResult;
import com.oo.service.DishService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 菜品管理
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Tag(name = "菜品管理")
@RequestMapping("dish")
@RestController
public class DishController {

    @Autowired
    private DishService dishService;

    /**
     * 新增菜品:调用菜品管理服务，新增菜品信息
     *
     * @param dishDTO 菜品信息入参
     * @return
     */
    @PostMapping("/add")
    @Operation(summary = "新增菜品:调用菜品管理服务，新增菜品信息")
    public RestResult<Boolean> addDish(@RequestBody @Validated(CreateGroup.class) DishDTO dishDTO) {
        Boolean result = dishService.addDish(dishDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 编辑菜品:调用菜品管理服务，更新菜品信息
     *
     * @param dishDTO 菜品信息入参
     * @return
     */
    @PutMapping("/update")
    @Operation(summary = "编辑菜品:调用菜品管理服务，更新菜品信息")
    public RestResult<Boolean> updateDish(@RequestBody @Validated(UpdateGroup.class) DishDTO dishDTO) {
        Boolean result = dishService.updateDish(dishDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 删除菜品:调用菜品管理服务，删除指定菜品
     *
     * @param dishDTO 菜品信息入参
     * @return
     */
    @DeleteMapping("/delete")
    @Operation(summary = "删除菜品:调用菜品管理服务，删除指定菜品")
    public RestResult<Boolean> deleteDish(@RequestBody @Validated DishDTO dishDTO) {
        Boolean result = dishService.deleteDish(dishDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 批量删除菜品:调用菜品管理服务，批量删除指定菜品
     *
     * @param dishIds 菜品 ID 列表
     * @return
     */
    @DeleteMapping("/deleteBatch")
    @Operation(summary = "批量删除菜品:调用菜品管理服务，批量删除指定菜品")
    public RestResult<Boolean> deleteBatchDishes(@RequestBody @Valid List<Long> dishIds) {
        Boolean result = dishService.deleteBatchDishes(dishIds);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 查询菜品:调用菜品管理服务，查询符合条件的菜品信息
     *
     * @param dishQuery 菜品查询条件入参
     * @return
     */
    @GetMapping("/query")
    @Operation(summary = "查询菜品:调用菜品管理服务，查询符合条件的菜品信息")
    public RestResult<PageResult<DishDO>> queryDishes(@Valid DishQuery dishQuery) {
        PageResult<DishDO> result = dishService.queryDishes(dishQuery);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }
}