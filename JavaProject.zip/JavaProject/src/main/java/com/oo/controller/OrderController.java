package com.oo.controller;

import com.oo.constant.ResultCodeConstant;
import com.oo.pojo.domain.ConfirmedMenuDO;
import com.oo.pojo.domain.DailyOrderDO;
import com.oo.pojo.dto.ConfirmationDTO;
import com.oo.pojo.dto.CreateGroup;
import com.oo.pojo.dto.DailyOrderDTO;
import com.oo.pojo.dto.RestResult;
import com.oo.pojo.query.ConfirmationDateQuery;
import com.oo.pojo.query.OrderDateQuery;
import com.oo.pojo.query.QueryGroup;
import com.oo.pojo.vo.PageResult;
import com.oo.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.lang.Boolean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 点单和菜单确认
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Tag(name = "点单和菜单确认")
@RequestMapping("order")
@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * 接口名称: 接收点单需求
     *
     * @param dailyOrderDTO 点单需求入参
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @Operation(summary = "接口名称: 接收点单需求")
    @ResponseBody
    public RestResult<Boolean> addDailyOrder(@RequestBody @Validated(CreateGroup.class) DailyOrderDTO dailyOrderDTO) {
        Boolean result = orderService.addDailyOrder(dailyOrderDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 接口名称: 确认制作的菜品
     *
     * @param confirmationDTO 菜品确认入参
     * @return
     */
    @RequestMapping(value = "/confirm", method = RequestMethod.POST)
    @Operation(summary = "接口名称: 确认制作的菜品")
    @ResponseBody
    public RestResult<Boolean> confirmMenu(@RequestBody @Validated(CreateGroup.class) ConfirmationDTO confirmationDTO) {
        Boolean result = orderService.confirmMenu(confirmationDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 接口名称: 获取当天点单需求
     *
     * @param orderDateQuery 查询点单日期入参
     * @return
     */
    @RequestMapping(value = "/todayOrders", method = RequestMethod.GET)
    @Operation(summary = "接口名称: 获取当天点单需求")
    public RestResult<PageResult<DailyOrderDO>> getTodayOrders(@Validated(QueryGroup.class) OrderDateQuery orderDateQuery) {
        PageResult<DailyOrderDO> result = orderService.getTodayOrders(orderDateQuery);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 接口名称: 获取已确认的菜单
     *
     * @param confirmationDateQuery 查询确认日期入参
     * @return
     */
    @RequestMapping(value = "/confirmedMenus", method = RequestMethod.GET)
    @Operation(summary = "接口名称: 获取已确认的菜单")
    public RestResult<PageResult<ConfirmedMenuDO>> getConfirmedMenus(@Validated(QueryGroup.class) ConfirmationDateQuery confirmationDateQuery) {
        PageResult<ConfirmedMenuDO> result = orderService.getConfirmedMenus(confirmationDateQuery);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }
}
