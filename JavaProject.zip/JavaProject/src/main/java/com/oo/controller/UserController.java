package com.oo.controller;

import com.oo.constant.ResultCodeConstant;
import com.oo.pojo.dto.CreateGroup;
import com.oo.pojo.dto.RestResult;
import com.oo.pojo.dto.UpdateGroup;
import com.oo.pojo.dto.UserLoginDTO;
import com.oo.pojo.dto.UserRegisterDTO;
import com.oo.pojo.dto.UserVerificationDTO;
import com.oo.pojo.query.QueryGroup;
import com.oo.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.lang.Boolean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户登录
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Tag(name = "用户登录")
@RequestMapping("user")
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * 用户登录
     *
     * @param userLoginDTO 用户登录请求入参对象
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @Operation(summary = "用户登录")
    @ResponseBody
    public RestResult<Boolean> userLogin(@RequestBody @Validated(QueryGroup.class) UserLoginDTO userLoginDTO) {
        Boolean result = userService.userLogin(userLoginDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 用户注册
     *
     * @param userRegisterDTO 用户注册请求入参对象
     * @return
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    @Operation(summary = "用户注册")
    @ResponseBody
    public RestResult<Boolean> userRegister(@RequestBody @Validated(CreateGroup.class) UserRegisterDTO userRegisterDTO) {
        Boolean result = userService.userRegister(userRegisterDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 验证验证码
     *
     * @param userVerificationDTO 用户验证码请求入参对象
     * @return
     */
    @RequestMapping(value = "/verifyCode", method = RequestMethod.POST)
    @Operation(summary = "验证验证码")
    @ResponseBody
    public RestResult<Boolean> verifyCode(@RequestBody @Validated(UpdateGroup.class) UserVerificationDTO userVerificationDTO) {
        Boolean result = userService.verifyCode(userVerificationDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 重置密码
     *
     * @param userVerificationDTO 用户验证码请求入参对象
     * @return
     */
    @RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
    @Operation(summary = "重置密码")
    @ResponseBody
    public RestResult<Boolean> resetPassword(@RequestBody @Validated(UpdateGroup.class) UserVerificationDTO userVerificationDTO) {
        Boolean result = userService.resetPassword(userVerificationDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }
}
