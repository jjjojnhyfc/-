package com.oo.controller;

import com.oo.constant.ResultCodeConstant;
import com.oo.pojo.domain.DishCategoryDO;
import com.oo.pojo.dto.CreateGroup;
import com.oo.pojo.dto.DeleteGroup;
import com.oo.pojo.dto.DishCategoryDTO;
import com.oo.pojo.dto.RestResult;
import com.oo.pojo.dto.UpdateGroup;
import com.oo.pojo.query.DishCategoryQuery;
import com.oo.service.DishCategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.lang.Boolean;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * DishCategoryController
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Tag(name = "DishCategoryController")
@RequestMapping("dishCategory")
@RestController
public class DishCategoryController {

    @Autowired
    private DishCategoryService dishCategoryService;

    /**
     * 新增菜品分类
     *
     * @param dishCategoryDTO 菜品分类新增和编辑的入参对象
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @Operation(summary = "新增菜品分类")
    @ResponseBody
    public RestResult<Boolean> addDishCategory(@RequestBody @Validated(CreateGroup.class) DishCategoryDTO dishCategoryDTO) {
        Boolean result = dishCategoryService.addDishCategory(dishCategoryDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 编辑菜品分类
     *
     * @param dishCategoryDTO 菜品分类新增和编辑的入参对象
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @Operation(summary = "编辑菜品分类")
    @ResponseBody
    public RestResult<Boolean> updateDishCategory(@RequestBody @Validated(UpdateGroup.class) DishCategoryDTO dishCategoryDTO) {
        Boolean result = dishCategoryService.updateDishCategory(dishCategoryDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 删除菜品分类
     *
     * @param dishCategoryQuery 菜品分类查询的入参对象
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    @Operation(summary = "删除菜品分类")
    @ResponseBody
    public RestResult<Boolean> deleteDishCategory(@RequestBody @Validated(DeleteGroup.class) DishCategoryQuery dishCategoryQuery) {
        Boolean result = dishCategoryService.deleteDishCategory(dishCategoryQuery);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 查询所有菜品分类
     *
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @Operation(summary = "查询所有菜品分类")
    public RestResult<List<DishCategoryDO>> listDishCategories() {
        List<DishCategoryDO> result = dishCategoryService.listDishCategories();
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }
}
