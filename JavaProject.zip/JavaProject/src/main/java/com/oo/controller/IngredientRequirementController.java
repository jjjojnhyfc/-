package com.oo.controller;

import com.oo.constant.ResultCodeConstant;
import com.oo.pojo.domain.IngredientDO;
import com.oo.pojo.domain.IngredientRequirementDO;
import com.oo.pojo.dto.CreateGroup;
import com.oo.pojo.dto.DeleteGroup;
import com.oo.pojo.dto.IngredientRequirementDTO;
import com.oo.pojo.dto.RestResult;
import com.oo.pojo.dto.UpdateGroup;
import com.oo.pojo.query.IngredientRequirementQuery;
import com.oo.pojo.query.QueryGroup;
import com.oo.service.IngredientRequirementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.lang.Boolean;
import java.lang.Object;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 食材需求分析
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Tag(name = "食材需求分析")
@RequestMapping("ingredient-requirement")
@RestController
public class IngredientRequirementController {

    @Autowired
    private IngredientRequirementService ingredientRequirementService;

    /**
     * 获取食材需求
     *
     * @param ingredientRequirementQuery 食材需求查询条件
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @Operation(summary = "获取食材需求")
    public RestResult<List<IngredientRequirementDO>> getIngredientRequirements(@Validated(QueryGroup.class) IngredientRequirementQuery ingredientRequirementQuery) {
        List<IngredientRequirementDO> result = ingredientRequirementService.getIngredientRequirements(ingredientRequirementQuery);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 列出已有食材
     *
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @Operation(summary = "列出已有食材")
    public RestResult<List<IngredientDO>> listIngredients() {
        List<IngredientDO> result = ingredientRequirementService.listIngredients();
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 更新食材需求
     *
     * @param ingredientRequirementDTO 食材需求信息
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    @Operation(summary = "更新食材需求")
    @ResponseBody
    public RestResult<Boolean> updateIngredientRequirement(@RequestBody @Validated(UpdateGroup.class) IngredientRequirementDTO ingredientRequirementDTO) {
        Boolean result = ingredientRequirementService.updateIngredientRequirement(ingredientRequirementDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 新增食材需求
     *
     * @param ingredientRequirementDTO 食材需求信息
     * @return
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @Operation(summary = "新增食材需求")
    @ResponseBody
    public RestResult<Boolean> addIngredientRequirement(@RequestBody @Validated(CreateGroup.class) IngredientRequirementDTO ingredientRequirementDTO) {
        Boolean result = ingredientRequirementService.addIngredientRequirement(ingredientRequirementDTO);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }

    /**
     * 删除食材需求
     *
     * @param requirementId
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    @Operation(summary = "删除食材需求")
    public RestResult<Boolean> deleteIngredientRequirement(@Validated(DeleteGroup.class) Object requirementId) {
        Boolean result = ingredientRequirementService.deleteIngredientRequirement(requirementId);
        return new RestResult<>(ResultCodeConstant.CODE_000000, ResultCodeConstant.CODE_000000_MSG, result);
    }
}
