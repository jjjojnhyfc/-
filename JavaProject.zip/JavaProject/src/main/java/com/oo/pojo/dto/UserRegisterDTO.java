package com.oo.pojo.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 用户注册请求入参对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class UserRegisterDTO {

    /**
     * 用户名
     */
    @NotBlank(groups = { CreateGroup.class }, message = "用户名不能为空")
    @Schema(description = "用户名")
    private String username;

    /**
     * 密码
     */
    @NotBlank(groups = { CreateGroup.class }, message = "密码不能为空")
    @Schema(description = "密码")
    private String password;

    /**
     * 邮箱
     */
    @Schema(description = "邮箱")
    private String email;

    /**
     * 电话
     */
    @Schema(description = "电话")
    private String phone;
}
