package com.oo.pojo.domain;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 食材信息
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IngredientDO {

    /**
     * 食材ID:食材ID
     */
    @Schema(description = "食材ID:食材ID")
    private Integer ingredientId;

    /**
     * 食材名称:食材名称
     */
    @Schema(description = "食材名称:食材名称")
    private String ingredientName;

    /**
     * 可用数量:可用数量
     */
    @Schema(description = "可用数量:可用数量")
    private java.math.BigDecimal quantityAvailable;

    /**
     * 单位:单位
     */
    @Schema(description = "单位:单位")
    private String unit;

    /**
     * 创建人:创建人
     */
    @Schema(description = "创建人:创建人")
    private Integer createBy;

    /**
     * 创建时间:创建时间
     */
    @Schema(description = "创建时间:创建时间")
    private java.util.Date createTime;

    /**
     * 修改人:修改人
     */
    @Schema(description = "修改人:修改人")
    private Integer updateBy;

    /**
     * 修改时间:修改时间
     */
    @Schema(description = "修改时间:修改时间")
    private java.util.Date updateTime;
}
