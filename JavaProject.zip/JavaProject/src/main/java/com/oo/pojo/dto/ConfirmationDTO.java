package com.oo.pojo.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品确认入参
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class ConfirmationDTO {

    /**
     * 菜品ID: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "菜品ID不能为空")
    @Schema(description = "菜品ID: 必填")
    private Integer dishId;

    /**
     * 确认日期: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "确认日期不能为空")
    @Schema(description = "确认日期: 必填")
    private Date confirmationDate;

    /**
     * 创建人ID: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "创建人ID不能为空")
    @Schema(description = "创建人ID: 必填")
    private Integer createBy;
}
