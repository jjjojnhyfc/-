package com.oo.pojo.domain;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 已确认菜单实体
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmedMenuDO {

    /**
     * 菜单ID: 自动生成
     */
    @Schema(description = "菜单ID: 自动生成")
    private Integer menuId;

    /**
     * 菜品ID
     */
    @Schema(description = "菜品ID")
    private Integer dishId;

    /**
     * 确认日期
     */
    @Schema(description = "确认日期")
    private Date confirmationDate;

    /**
     * 创建人
     */
    @Schema(description = "创建人")
    private Integer createBy;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private Date createTime;
}
