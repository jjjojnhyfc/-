package com.oo.pojo.domain;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品分类实体对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DishCategoryDO {

    /**
     * 类别ID
     */
    @Schema(description = "类别ID")
    private Integer categoryId;

    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    private String categoryName;

    /**
     * 创建人
     */
    @Schema(description = "创建人")
    private Integer createBy;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private Date createTime;

    /**
     * 修改人
     */
    @Schema(description = "修改人")
    private Integer updateBy;

    /**
     * 修改时间
     */
    @Schema(description = "修改时间")
    private Date updateTime;
}
