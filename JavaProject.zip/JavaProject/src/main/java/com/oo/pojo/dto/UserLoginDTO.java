package com.oo.pojo.dto;

import lombok.Data;
import com.oo.pojo.query.QueryGroup;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
public class UserLoginDTO {
    /**
     * 用户ID
     */
    @Schema(description = "用户ID")
    private int userId; // 添加 userId 字段

    /**
     * 用户名
     */
    @NotBlank(groups = { QueryGroup.class }, message = "用户名不能为空")
    @Schema(description = "用户名")
    private String username;

    /**
     * 密码
     */
    @NotBlank(groups = { QueryGroup.class }, message = "密码不能为空")
    @Schema(description = "密码")
    private String password;

    /**
     * 验证码
     */
    @NotBlank(groups = { QueryGroup.class }, message = "验证码不能为空")
    @Schema(description = "验证码")
    private String verificationCode;
}