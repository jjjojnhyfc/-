package com.oo.pojo.query;

import lombok.Data;
import lombok.AllArgsConstructor;
import com.oo.pojo.dto.DeleteGroup;
import jakarta.validation.constraints.NotNull;
import lombok.NoArgsConstructor;
import jakarta.validation.groups.Default;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品分类查询的入参对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DishCategoryQuery {

    /**
     * 类别ID: 必填
     */
    @NotNull(groups = { DeleteGroup.class, Default.class }, message = "类别ID不能为空")
    @Schema(description = "类别ID: 必填")
    private Integer categoryId;
}
