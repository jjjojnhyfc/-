package com.oo.pojo.domain;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 每日点单实体
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DailyOrderDO {

    /**
     * 订单ID: 自动生成
     */
    @Schema(description = "订单ID: 自动生成")
    private Integer orderId;

    /**
     * 用户ID
     */
    @Schema(description = "用户ID")
    private Integer userId;

    /**
     * 菜品ID
     */
    @Schema(description = "菜品ID")
    private Integer dishId;

    /**
     * 数量
     */
    @Schema(description = "数量")
    private Integer quantity;

    /**
     * 点单日期
     */
    @Schema(description = "点单日期")
    private Date orderDate;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private Date createTime;
}
