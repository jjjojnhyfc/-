package com.oo.pojo.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import jakarta.validation.constraints.NotNull;
import lombok.NoArgsConstructor;
import jakarta.validation.groups.Default;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品分类新增和编辑的入参对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DishCategoryDTO {

    /**
     * 类别ID: 编辑时必填
     */
    @NotNull(groups = { UpdateGroup.class, Default.class }, message = "类别ID不能为空")
    @Schema(description = "类别ID: 编辑时必填")
    private Integer categoryId;

    /**
     * 类别名称: 必填
     */
    @NotBlank(groups = { CreateGroup.class, UpdateGroup.class, Default.class }, message = "类别名称不能为空")
    @Schema(description = "类别名称: 必填")
    private String categoryName;

    /**
     * 创建人: 新增时必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "创建人不能为空")
    @Schema(description = "创建人: 新增时必填")
    private Integer createBy;

    /**
     * 修改人: 编辑时必填
     */
    @NotNull(groups = { UpdateGroup.class, Default.class }, message = "修改人不能为空")
    @Schema(description = "修改人: 编辑时必填")
    private Integer updateBy;
}
