package com.oo.pojo.domain;

import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品信息实体
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class DishDO {

    /**
     * 菜品ID: 必填，主键，自增
     */
    @Schema(description = "菜品ID: 必填，主键，自增")
    private Integer dishId;

    /**
     * 菜品名称: 必填
     */
    @Schema(description = "菜品名称: 必填")
    private String dishName;

    /**
     * 类别ID: 选填
     */
    @Schema(description = "类别ID: 选填")
    private Integer categoryId;

    /**
     * 菜品描述: 选填
     */
    @Schema(description = "菜品描述: 选填")
    private String description;

    /**
     * 菜品价格: 选填
     */
    @Schema(description = "菜品价格: 选填")
    private BigDecimal price;

    /**
     * 创建人: 选填
     */
    @Schema(description = "创建人: 选填")
    private Integer createBy;

    /**
     * 创建时间: 选填
     */
    @Schema(description = "创建时间: 选填")
    private Date createTime;

    /**
     * 修改人: 选填
     */
    @Schema(description = "修改人: 选填")
    private Integer updateBy;

    /**
     * 修改时间: 选填
     */
    @Schema(description = "修改时间: 选填")
    private Date updateTime;
}
