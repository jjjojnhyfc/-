package com.oo.pojo.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 用户验证码请求入参对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class UserVerificationDTO {

    /**
     * 用户ID
     */
    @NotNull(groups = { UpdateGroup.class }, message = "用户ID不能为空")
    @Schema(description = "用户ID")
    private Integer userId;

    /**
     * 验证码
     */
    @NotBlank(groups = { UpdateGroup.class }, message = "验证码不能为空")
    @Schema(description = "验证码")
    private String verificationCode;

    /**
     * 新密码
     */
    @Schema(description = "新密码")
    private String newPassword;
}
