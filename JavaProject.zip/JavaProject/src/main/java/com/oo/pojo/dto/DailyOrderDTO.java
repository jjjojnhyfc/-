package com.oo.pojo.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import com.oo.pojo.query.QueryGroup;
import jakarta.validation.groups.Default;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 点单需求入参
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class DailyOrderDTO {

    /**
     * 用户ID: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "用户ID不能为空")
    @Schema(description = "用户ID: 必填")
    private Integer userId;

    /**
     * 菜品ID: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "菜品ID不能为空")
    @Schema(description = "菜品ID: 必填")
    private Integer dishId;

    /**
     * 数量: 必填
     */
    @NotNull(groups = { CreateGroup.class, Default.class }, message = "数量不能为空")
    @Schema(description = "数量: 必填")
    private Integer quantity;

    /**
     * 点单日期: 必填
     */
    @NotNull(groups = { CreateGroup.class, QueryGroup.class, Default.class }, message = "点单日期不能为空")
    @Schema(description = "点单日期: 必填")
    private Date orderDate;
}
