package com.oo.pojo.dto;

/**
 * DeleteGroup
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface DeleteGroup {
}
