package com.oo.pojo.query;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.groups.Default;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查询点单日期入参
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class OrderDateQuery {

    /**
     * 点单日期: 必填
     */
    @NotNull(groups = { QueryGroup.class, Default.class }, message = "点单日期不能为空")
    @Schema(description = "点单日期: 必填")
    private Date orderDate;
}
