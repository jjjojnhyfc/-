package com.oo.pojo.dto;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品信息入参
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class DishDTO {

    /**
     * 菜品ID: 必填
     */
    @NotNull(groups = { UpdateGroup.class }, message = "菜品ID不能为空")
    @Schema(description = "菜品ID: 必填")
    private Integer dishId;

    /**
     * 菜品名称: 必填
     */
    @NotBlank(groups = { CreateGroup.class }, message = "菜品名称不能为空")
    @Schema(description = "菜品名称: 必填")
    private String dishName;

    /**
     * 类别ID: 选填
     */
    @Schema(description = "类别ID: 选填")
    private Integer categoryId;

    /**
     * 菜品描述: 选填
     */
    @Schema(description = "菜品描述: 选填")
    private String description;

    /**
     * 菜品价格: 选填
     */
    @Positive(groups = { CreateGroup.class, UpdateGroup.class }, message = "菜品价格必须为正数")
    @Schema(description = "菜品价格: 选填")
    private BigDecimal price;

    /**
     * 创建人: 选填
     */
    @Schema(description = "创建人: 选填")
    private Integer createBy;

    /**
     * 修改人: 选填
     */
    @Schema(description = "修改人: 选填")
    private Integer updateBy;
}
