package com.oo.pojo.query;

/**
 * QueryGroup
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface QueryGroup {
}
