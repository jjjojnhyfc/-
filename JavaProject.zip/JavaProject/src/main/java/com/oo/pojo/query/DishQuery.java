package com.oo.pojo.query;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 菜品查询条件入参
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class DishQuery {

    /**
     * 菜品ID: 选填
     */
    @Schema(description = "菜品ID: 选填")
    private Integer dishId;

    /**
     * 菜品名称: 选填
     */
    @Schema(description = "菜品名称: 选填")
    private String dishName;

    /**
     * 类别ID: 选填
     */
    @Schema(description = "类别ID: 选填")
    private Integer categoryId;

    /**
     * 页码: 必填
     */
    @Schema(description = "页码: 必填")
    private int pageIndex;

    /**
     * 每页数量: 必填
     */
    @Schema(description = "每页数量: 必填")
    private int pageSize;
}
