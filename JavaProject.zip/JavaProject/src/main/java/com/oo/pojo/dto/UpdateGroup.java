package com.oo.pojo.dto;

/**
 * UpdateGroup
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface UpdateGroup {
}
