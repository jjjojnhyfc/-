package com.oo.pojo.domain;

import lombok.Data;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 用户验证码实体对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class UserVerificationDO {

    /**
     * 验证码ID
     */
    @Schema(description = "验证码ID")
    private Integer codeId;

    /**
     * 用户ID
     */
    @Schema(description = "用户ID")
    private Integer userId;

    /**
     * 验证码
     */
    @Schema(description = "验证码")
    private String verificationCode;

    /**
     * 过期时间
     */
    @Schema(description = "过期时间")
    private Date expirationTime;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private Date createTime;
}
