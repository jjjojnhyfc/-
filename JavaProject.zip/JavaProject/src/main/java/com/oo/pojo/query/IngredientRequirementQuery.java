package com.oo.pojo.query;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 食材需求查询条件
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class IngredientRequirementQuery {

    /**
     * 日期:日期，必填
     */
    @NotNull(groups = { QueryGroup.class }, message = "日期不能为空")
    @Schema(description = "日期:日期，必填")
    private Date date;
}
