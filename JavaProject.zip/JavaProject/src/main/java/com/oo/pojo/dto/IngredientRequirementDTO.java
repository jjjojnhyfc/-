package com.oo.pojo.dto;

import lombok.Data;
import lombok.AllArgsConstructor;
import jakarta.validation.constraints.NotNull;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import jakarta.validation.constraints.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 食材需求信息
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IngredientRequirementDTO {

    /**
     * 需求ID:需求ID，必填
     */
    @NotNull(groups = { UpdateGroup.class, DeleteGroup.class }, message = "需求ID不能为空")
    @Schema(description = "需求ID:需求ID，必填")
    private Integer requirementId;

    /**
     * 菜单ID:菜单ID，必填
     */
    @NotNull(groups = { CreateGroup.class, UpdateGroup.class }, message = "菜单ID不能为空")
    @Schema(description = "菜单ID:菜单ID，必填")
    private Integer menuId;

    /**
     * 食材ID:食材ID，必填
     */
    @NotNull(groups = { CreateGroup.class, UpdateGroup.class }, message = "食材ID不能为空")
    @Schema(description = "食材ID:食材ID，必填")
    private Integer ingredientId;

    /**
     * 所需数量:所需数量，必填
     */
    @NotNull(groups = { CreateGroup.class, UpdateGroup.class }, message = "所需数量不能为空")
    @Schema(description = "所需数量:所需数量，必填")
    private java.math.BigDecimal requiredQuantity;

    /**
     * 单位:单位，必填
     */
    @NotBlank(groups = { CreateGroup.class, UpdateGroup.class }, message = "单位不能为空")
    @Schema(description = "单位:单位，必填")
    private String unit;
}
