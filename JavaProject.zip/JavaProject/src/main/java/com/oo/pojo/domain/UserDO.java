package com.oo.pojo.domain;

import lombok.Data;
import java.util.Date;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 用户实体对象
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Data
public class UserDO {

    /**
     * 用户ID
     */
    @Schema(description = "用户ID")
    private Integer id;

    /**
     * 用户名
     */
    @Schema(description = "用户名")
    private String username;

    /**
     * 密码
     */
    @Schema(description = "密码")
    private String password;

    /**
     * 邮箱
     */
    @Schema(description = "邮箱")
    private String email;

    /**
     * 电话
     */
    @Schema(description = "电话")
    private String phone;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private Date createTime;

    /**
     * 修改时间
     */
    @Schema(description = "修改时间")
    private Date updateTime;
}
