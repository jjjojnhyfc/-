package com.oo.constant;

import java.lang.String;

/**
 * 响应码常量
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public final class ResultCodeConstant {
  public static final String CODE_000001 = "000001";

  public static final String CODE_000001_MSG = "用户名或密码错误";

  public static final String CODE_000000 = "000000";

  public static final String CODE_000000_MSG = "调用成功";

  public static final String CODE_999999 = "999999";

  public static final String CODE_999999_MSG = "系统异常";

  public static final String CODE_000002 = "000002";
  public static final String CODE_000002_MSG = "参数错误：菜品 ID 列表不能为空";
}
