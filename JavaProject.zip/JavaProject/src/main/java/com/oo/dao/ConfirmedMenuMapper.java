package com.oo.dao;

import java.util.List;
import com.oo.pojo.domain.ConfirmedMenuDO;
import org.apache.ibatis.annotations.Param;
import java.util.Date;

/**
 * ConfirmedMenuMapper
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface ConfirmedMenuMapper {

    /**
     * 保存确认的菜品到已确认菜单表
     *
     * @Param confirmedMenuDO
     * @Return int
     */
    int insert(ConfirmedMenuDO confirmedMenuDO);

    /**
     * 查询已确认的菜单
     *
     * @Param confirmationDate
     * @Return List<ConfirmedMenuDO>
     */
    List<ConfirmedMenuDO> selectByConfirmationDate(@Param("confirmationDate") Date confirmationDate);
}
