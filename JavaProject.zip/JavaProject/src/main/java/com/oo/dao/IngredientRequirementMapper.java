package com.oo.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.oo.pojo.domain.IngredientRequirementDO;
import java.util.Date;

/**
 * IngredientRequirementMapper
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface IngredientRequirementMapper {

    /**
     * 根据需求ID更新食材需求
     *
     * @Param ingredientRequirementDO 食材需求信息
     * @Return 更新结果
     */
    int updateById(IngredientRequirementDO ingredientRequirementDO);

    /**
     * 新增食材需求
     *
     * @Param ingredientRequirementDO 食材需求信息
     * @Return 新增结果
     */
    int insert(IngredientRequirementDO ingredientRequirementDO);

    /**
     * 根据需求ID删除食材需求
     *
     * @Param requirementId 需求ID
     * @Return 删除结果
     */
    int deleteById(int requirementId);

    /**
     * 根据确认日期查询食材需求
     *
     * @Param confirmationDate 确认日期
     * @Return 食材需求列表
     */
    List<IngredientRequirementDO> selectByConfirmationDate(java.util.Date confirmationDate);
}
