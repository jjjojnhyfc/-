package com.oo.dao;

import java.util.List;
import com.oo.pojo.domain.IngredientDO;

/**
 * IngredientMapper
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface IngredientMapper {

    /**
     * 查询所有可用食材
     *
     * @Return 食材列表
     */
    List<IngredientDO> selectAll();
}
