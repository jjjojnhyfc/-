package com.oo.dao;

import java.util.List;
import com.oo.pojo.domain.DailyOrderDO;
import org.apache.ibatis.annotations.Param;
import java.util.Date;

/**
 * DailyOrderMapper
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface DailyOrderMapper {

    /**
     * 保存点单需求到每日点单表
     *
     * @Param dailyOrderDO
     * @Return int
     */
    int insert(DailyOrderDO dailyOrderDO);

    /**
     * 查询当天的点单需求
     *
     * @Param orderDate
     * @Return List<DailyOrderDO>
     */
    List<DailyOrderDO> selectByOrderDate(@Param("orderDate") Date orderDate);
}
