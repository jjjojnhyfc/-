package com.oo.dao;

import java.util.List;
import com.oo.pojo.query.DishQuery;
import com.oo.pojo.domain.DishDO;
import org.apache.ibatis.annotations.Param;

/**
 * 菜品管理Mapper接口
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface DishMapper {

    /**
     * 新增菜品:新增菜品信息
     * @Param dishDO: 菜品信息实体
     * @Return int: 影响行数
     */
    int insert(DishDO dishDO);

    /**
     * 更新菜品:更新菜品信息
     * @Param dishDO: 菜品信息实体
     * @Return int: 影响行数
     */
    int updateById(DishDO dishDO);

    /**
     * 删除菜品:删除指定菜品
     * @Param dishId: 菜品ID
     * @Return int: 影响行数
     */
    int deleteById(int dishId);

    /**
     * 批量删除菜品:批量删除指定菜品
     * @Param dishIds: 菜品ID列表
     * @Return int: 影响行数
     */
    int deleteBatchByIds(@Param("dishIds") List<Integer> dishIds);

    /**
     * 查询菜品:查询符合条件的菜品信息总数
     * @Param dishQuery: 菜品查询条件实体
     * @Return int: 符合条件的菜品总数
     */
    int countDishes(DishQuery dishQuery);

    /**
     * 查询菜品:分页查询符合条件的菜品信息
     * @Param dishQuery: 菜品查询条件实体
     * @Param start: 页码开始位置
     * @Param pageSize: 每页数量
     * @Return List<DishDO>: 菜品信息实体列表
     */
    List<DishDO> pageDishes(@Param("dishQuery") DishQuery dishQuery, @Param("start") int start, @Param("pageSize") int pageSize);
}
