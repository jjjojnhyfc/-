package com.oo.dao;

import com.oo.pojo.domain.UserDO;
import org.apache.ibatis.annotations.Param;

/**
 * 用户Mapper接口
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface UserMapper {

    /**
     * 根据用户名和密码查询用户
     *
     * @Param username 用户名
     * @Param password 密码
     * @Return UserDO
     */
    UserDO selectByUsernameAndPassword(String username, String password);

    /**
     * 根据用户名查询用户
     *
     * @Param username 用户名
     * @Return UserDO
     */
    UserDO selectByUsername(String username);

    /**
     * 插入新用户
     *
     * @Param userDO 用户实体对象
     * @Return 插入结果
     */
    int insert(UserDO userDO);

    /**
     * 更新用户密码
     *
     * @Param userDO 用户实体对象
     * @Return 更新结果
     */
    int updatePassword(UserDO userDO);
}
