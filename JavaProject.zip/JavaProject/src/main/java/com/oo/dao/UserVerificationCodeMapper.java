package com.oo.dao;

import com.oo.pojo.domain.UserVerificationDO;
import org.apache.ibatis.annotations.Param;

/**
 * 用户验证码Mapper接口
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface UserVerificationCodeMapper {

    /**
     * 根据用户ID和验证码查询用户验证码
     *
     * @Param userId 用户ID
     * @Param verificationCode 验证码
     * @Return UserVerificationDO
     */
    UserVerificationDO selectByUserIdAndCode(Integer userId, String verificationCode);

    /**
     * 插入新用户验证码
     *
     * @Param userVerificationDO 用户验证码实体对象
     * @Return 插入结果
     */
    int insert(UserVerificationDO userVerificationDO);
}
