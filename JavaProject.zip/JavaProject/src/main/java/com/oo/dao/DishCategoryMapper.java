package com.oo.dao;

import com.oo.pojo.domain.DishCategoryDO;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * DishCategoryMapper
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface DishCategoryMapper {

    /**
     * 新增菜品分类
     *
     * @Param dishCategoryDO 新增的菜品分类对象
     * @Return 影响记录数
     */
    int insert(DishCategoryDO dishCategoryDO);

    /**
     * 更新菜品分类
     *
     * @Param dishCategoryDO 更新的菜品分类对象
     * @Return 影响记录数
     */
    int updateById(DishCategoryDO dishCategoryDO);

    /**
     * 删除菜品分类
     *
     * @Param categoryId 菜品分类ID
     * @Return 影响记录数
     */
    int deleteById(Integer categoryId);

    /**
     * 查询所有菜品分类
     *
     * @Return 菜品分类列表
     */
    List<DishCategoryDO> selectAll();
}
