package com.oo.service.impl;

import com.oo.dao.UserMapper;
import com.oo.dao.UserVerificationCodeMapper;
import com.oo.pojo.dto.UserLoginDTO;
import com.oo.pojo.dto.UserRegisterDTO;
import com.oo.pojo.dto.UserVerificationDTO;
import com.oo.service.UserService;
import java.lang.Boolean;
import java.lang.Override;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo.pojo.domain.UserVerificationDO;
import com.oo.exception.BusinessException;
import com.oo.pojo.domain.UserDO;
import java.util.Map;
import com.oo.constant.ResultCodeConstant;
import java.util.Date;

/**
 * 用户登录的实现
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserVerificationCodeMapper userVerificationCodeMapper;

    @Override
    public Boolean userLogin(UserLoginDTO userLoginDTO) {
        UserDO userDO = userMapper.selectByUsernameAndPassword(userLoginDTO.getUsername(), userLoginDTO.getPassword());
        if (userDO == null) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        UserVerificationDO verificationDO = userVerificationCodeMapper.selectByUserIdAndCode(userLoginDTO.getUserId(), userLoginDTO.getVerificationCode());
        if (verificationDO == null || verificationDO.getExpirationTime().before(new Date())) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        return true;
    }

    @Override
    public Boolean userRegister(UserRegisterDTO userRegisterDTO) {
        UserDO existingUser = userMapper.selectByUsername(userRegisterDTO.getUsername());
        if (existingUser != null) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        UserDO newUser = new UserDO();
        newUser.setUsername(userRegisterDTO.getUsername());
        newUser.setPassword(userRegisterDTO.getPassword());
        newUser.setEmail(userRegisterDTO.getEmail());
        newUser.setPhone(userRegisterDTO.getPhone());
        int result = userMapper.insert(newUser);
        if (result <= 0) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        return true;
    }

    @Override
    public Boolean verifyCode(UserVerificationDTO userVerificationDTO) {
        UserVerificationDO verificationDO = userVerificationCodeMapper.selectByUserIdAndCode(userVerificationDTO.getUserId(), userVerificationDTO.getVerificationCode());
        if (verificationDO == null || verificationDO.getExpirationTime().before(new Date())) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        return true;
    }

    @Override
    public Boolean resetPassword(UserVerificationDTO userVerificationDTO) {
        UserVerificationDO verificationDO = userVerificationCodeMapper.selectByUserIdAndCode(userVerificationDTO.getUserId(), userVerificationDTO.getVerificationCode());
        if (verificationDO == null || verificationDO.getExpirationTime().before(new Date())) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        UserDO userDO = new UserDO();
        userDO.setId(userVerificationDTO.getUserId());
        userDO.setPassword(userVerificationDTO.getNewPassword());
        int updateResult = userMapper.updatePassword(userDO);
        if (updateResult <= 0) {
            throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
        }
        return true;
    }
}
