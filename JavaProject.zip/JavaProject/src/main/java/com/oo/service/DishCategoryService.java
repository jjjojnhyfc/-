package com.oo.service;

import com.oo.pojo.domain.DishCategoryDO;
import com.oo.pojo.dto.DishCategoryDTO;
import com.oo.pojo.query.DishCategoryQuery;
import java.lang.Boolean;
import java.util.List;

/**
 * DishCategoryService
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface DishCategoryService {

    /**
     * 新增菜品分类
     *
     * @param dishCategoryDTO 菜品分类新增和编辑的入参对象
     * @return
     */
    Boolean addDishCategory(DishCategoryDTO dishCategoryDTO);

    /**
     * 编辑菜品分类
     *
     * @param dishCategoryDTO 菜品分类新增和编辑的入参对象
     * @return
     */
    Boolean updateDishCategory(DishCategoryDTO dishCategoryDTO);

    /**
     * 删除菜品分类
     *
     * @param dishCategoryQuery 菜品分类查询的入参对象
     * @return
     */
    Boolean deleteDishCategory(DishCategoryQuery dishCategoryQuery);

    /**
     * 查询所有菜品分类
     *
     * @return
     */
    List<DishCategoryDO> listDishCategories();
}
