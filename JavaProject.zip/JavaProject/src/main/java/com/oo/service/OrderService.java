package com.oo.service;

import com.oo.pojo.domain.ConfirmedMenuDO;
import com.oo.pojo.domain.DailyOrderDO;
import com.oo.pojo.dto.ConfirmationDTO;
import com.oo.pojo.dto.DailyOrderDTO;
import com.oo.pojo.query.ConfirmationDateQuery;
import com.oo.pojo.query.OrderDateQuery;
import com.oo.pojo.vo.PageResult;
import java.lang.Boolean;

/**
 * 点单和菜单确认
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface OrderService {

    /**
     * 接口名称: 接收点单需求
     *
     * @param dailyOrderDTO 点单需求入参
     * @return
     */
    Boolean addDailyOrder(DailyOrderDTO dailyOrderDTO);

    /**
     * 接口名称: 确认制作的菜品
     *
     * @param confirmationDTO 菜品确认入参
     * @return
     */
    Boolean confirmMenu(ConfirmationDTO confirmationDTO);

    /**
     * 接口名称: 获取当天点单需求
     *
     * @param orderDateQuery 查询点单日期入参
     * @return
     */
    PageResult<DailyOrderDO> getTodayOrders(OrderDateQuery orderDateQuery);

    /**
     * 接口名称: 获取已确认的菜单
     *
     * @param confirmationDateQuery 查询确认日期入参
     * @return
     */
    PageResult<ConfirmedMenuDO> getConfirmedMenus(ConfirmationDateQuery confirmationDateQuery);
}
