package com.oo.service;

import com.oo.pojo.dto.UserLoginDTO;
import com.oo.pojo.dto.UserRegisterDTO;
import com.oo.pojo.dto.UserVerificationDTO;
import java.lang.Boolean;

/**
 * 用户登录
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface UserService {

    /**
     * 用户登录
     *
     * @param userLoginDTO 用户登录请求入参对象
     * @return
     */
    Boolean userLogin(UserLoginDTO userLoginDTO);

    /**
     * 用户注册
     *
     * @param userRegisterDTO 用户注册请求入参对象
     * @return
     */
    Boolean userRegister(UserRegisterDTO userRegisterDTO);

    /**
     * 验证验证码
     *
     * @param userVerificationDTO 用户验证码请求入参对象
     * @return
     */
    Boolean verifyCode(UserVerificationDTO userVerificationDTO);

    /**
     * 重置密码
     *
     * @param userVerificationDTO 用户验证码请求入参对象
     * @return
     */
    Boolean resetPassword(UserVerificationDTO userVerificationDTO);
}
