package com.oo.service.impl;

import com.oo.dao.DishMapper;
import com.oo.exception.BusinessException;
import com.oo.pojo.domain.DishDO;
import com.oo.pojo.dto.DishDTO;
import com.oo.pojo.query.DishQuery;
import com.oo.pojo.vo.PageResult;
import com.oo.service.DishService;
import com.oo.constant.ResultCodeConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors; // 导入用于转换的工具类

@Service
public class DishServiceImpl implements DishService {

    @Autowired
    private DishMapper dishMapper;

    @Override
    public Boolean addDish(DishDTO dishDTO) {
        DishDO dishDO = new DishDO();
        dishDO.setDishName(dishDTO.getDishName());
        dishDO.setCategoryId(dishDTO.getCategoryId());
        dishDO.setDescription(dishDTO.getDescription());
        dishDO.setPrice(dishDTO.getPrice());
        dishDO.setCreateBy(dishDTO.getCreateBy());
        dishDO.setCreateTime(new Date());
        int result = dishMapper.insert(dishDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean updateDish(DishDTO dishDTO) {
        DishDO dishDO = new DishDO();
        dishDO.setDishId(dishDTO.getDishId());
        dishDO.setDishName(dishDTO.getDishName());
        dishDO.setCategoryId(dishDTO.getCategoryId());
        dishDO.setDescription(dishDTO.getDescription());
        dishDO.setPrice(dishDTO.getPrice());
        dishDO.setUpdateBy(dishDTO.getUpdateBy());
        dishDO.setUpdateTime(new Date());
        int result = dishMapper.updateById(dishDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean deleteDish(DishDTO dishDTO) {
        int result = dishMapper.deleteById(dishDTO.getDishId());
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean deleteBatchDishes(List<Long> dishIds) {
        // 参数校验：确保 dishIds 不为空
        if (dishIds == null || dishIds.isEmpty()) {
            throw new BusinessException(ResultCodeConstant.CODE_000002, "菜品 ID 列表不能为空");
        }

        // 将 List<Long> 转换为 List<Integer>
        List<Integer> dishIdsAsInt = dishIds.stream()
                .map(id -> id.intValue())
                .collect(Collectors.toList());

        // 调用 Mapper 的批量删除方法
        int result = dishMapper.deleteBatchByIds(dishIdsAsInt);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public PageResult<DishDO> queryDishes(DishQuery dishQuery) {
        int start = (dishQuery.getPageIndex() - 1) * dishQuery.getPageSize();
        int pageSize = dishQuery.getPageSize();
        int totalRecords = dishMapper.countDishes(dishQuery);
        long totalPages = (totalRecords + pageSize - 1) / pageSize;

        List<DishDO> dishes;
        if (totalRecords > 0) {
            dishes = dishMapper.pageDishes(dishQuery, start, pageSize);
        } else {
            dishes = null; // 如果没有记录，返回 null 或空列表
        }

        // 使用正确的构造函数参数顺序
        PageResult<DishDO> pageResult = new PageResult<>(totalRecords, totalPages, dishQuery.getPageIndex(), pageSize, dishes);
        return pageResult;
    }
}