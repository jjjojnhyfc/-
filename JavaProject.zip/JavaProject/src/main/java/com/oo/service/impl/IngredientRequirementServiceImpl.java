package com.oo.service.impl;

import com.oo.dao.ConfirmedMenuMapper;
import com.oo.dao.IngredientMapper;
import com.oo.dao.IngredientRequirementMapper;
import com.oo.pojo.domain.IngredientDO;
import com.oo.pojo.domain.IngredientRequirementDO;
import com.oo.pojo.dto.IngredientRequirementDTO;
import com.oo.pojo.query.IngredientRequirementQuery;
import com.oo.service.IngredientRequirementService;
import java.lang.Boolean;
import java.lang.Object;
import java.lang.Override;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo.exception.BusinessException;
import java.util.Map;
import com.oo.constant.ResultCodeConstant;
import java.util.Date;

/**
 * 食材需求分析的实现
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Service
public class IngredientRequirementServiceImpl implements IngredientRequirementService {

    @Autowired
    private ConfirmedMenuMapper confirmedMenuMapper;

    @Autowired
    private IngredientRequirementMapper ingredientRequirementMapper;

    @Autowired
    private IngredientMapper ingredientMapper;

    @Override
    public List<IngredientRequirementDO> getIngredientRequirements(IngredientRequirementQuery ingredientRequirementQuery) {
        try {
            Date date = ingredientRequirementQuery.getDate();
            List<IngredientRequirementDO> ingredientRequirements = ingredientRequirementMapper.selectByConfirmationDate(date);
            return ingredientRequirements;
        } catch (Exception e) {
            throw new BusinessException(ResultCodeConstant.CODE_999999, ResultCodeConstant.CODE_999999_MSG);
        }
    }

    @Override
    public List<IngredientDO> listIngredients() {
        try {
            List<IngredientDO> ingredients = ingredientMapper.selectAll();
            return ingredients;
        } catch (Exception e) {
            throw new BusinessException(ResultCodeConstant.CODE_999999, ResultCodeConstant.CODE_999999_MSG);
        }
    }

    @Override
    public Boolean updateIngredientRequirement(IngredientRequirementDTO ingredientRequirementDTO) {
        try {
            IngredientRequirementDO ingredientRequirementDO = new IngredientRequirementDO();
            ingredientRequirementDO.setRequirementId(ingredientRequirementDTO.getRequirementId());
            ingredientRequirementDO.setMenuId(ingredientRequirementDTO.getMenuId());
            ingredientRequirementDO.setIngredientId(ingredientRequirementDTO.getIngredientId());
            ingredientRequirementDO.setRequiredQuantity(ingredientRequirementDTO.getRequiredQuantity());
            ingredientRequirementDO.setUnit(ingredientRequirementDTO.getUnit());
            int result = ingredientRequirementMapper.updateById(ingredientRequirementDO);
            return result > 0;
        } catch (Exception e) {
            throw new BusinessException(ResultCodeConstant.CODE_999999, ResultCodeConstant.CODE_999999_MSG);
        }
    }

    @Override
    public Boolean addIngredientRequirement(IngredientRequirementDTO ingredientRequirementDTO) {
        try {
            IngredientRequirementDO ingredientRequirementDO = new IngredientRequirementDO();
            ingredientRequirementDO.setMenuId(ingredientRequirementDTO.getMenuId());
            ingredientRequirementDO.setIngredientId(ingredientRequirementDTO.getIngredientId());
            ingredientRequirementDO.setRequiredQuantity(ingredientRequirementDTO.getRequiredQuantity());
            ingredientRequirementDO.setUnit(ingredientRequirementDTO.getUnit());
            int result = ingredientRequirementMapper.insert(ingredientRequirementDO);
            return result > 0;
        } catch (Exception e) {
            throw new BusinessException(ResultCodeConstant.CODE_999999, ResultCodeConstant.CODE_999999_MSG);
        }
    }

    @Override
    public Boolean deleteIngredientRequirement(Object requirementId) {
        try {
            int result = ingredientRequirementMapper.deleteById((Integer) requirementId);
            return result > 0;
        } catch (Exception e) {
            throw new BusinessException(ResultCodeConstant.CODE_999999, ResultCodeConstant.CODE_999999_MSG);
        }
    }
}
