package com.oo.service.impl;

import com.oo.dao.ConfirmedMenuMapper;
import com.oo.dao.DailyOrderMapper;
import com.oo.pojo.domain.ConfirmedMenuDO;
import com.oo.pojo.domain.DailyOrderDO;
import com.oo.pojo.dto.ConfirmationDTO;
import com.oo.pojo.dto.DailyOrderDTO;
import com.oo.pojo.query.ConfirmationDateQuery;
import com.oo.pojo.query.OrderDateQuery;
import com.oo.pojo.vo.PageResult;
import com.oo.service.OrderService;
import java.lang.Boolean;
import java.lang.Override;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo.exception.BusinessException;
import java.util.List;
import java.util.Map;
import com.oo.constant.ResultCodeConstant;
import java.util.Date;

/**
 * 点单和菜单确认的实现
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private ConfirmedMenuMapper confirmedMenuMapper;

    @Autowired
    private DailyOrderMapper dailyOrderMapper;

    @Override
    public Boolean addDailyOrder(DailyOrderDTO dailyOrderDTO) {
        DailyOrderDO dailyOrderDO = new DailyOrderDO();
        dailyOrderDO.setUserId(dailyOrderDTO.getUserId());
        dailyOrderDO.setDishId(dailyOrderDTO.getDishId());
        dailyOrderDO.setQuantity(dailyOrderDTO.getQuantity());
        dailyOrderDO.setOrderDate(dailyOrderDTO.getOrderDate());
        int result = dailyOrderMapper.insert(dailyOrderDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean confirmMenu(ConfirmationDTO confirmationDTO) {
        ConfirmedMenuDO confirmedMenuDO = new ConfirmedMenuDO();
        confirmedMenuDO.setDishId(confirmationDTO.getDishId());
        confirmedMenuDO.setConfirmationDate(confirmationDTO.getConfirmationDate());
        confirmedMenuDO.setCreateBy(confirmationDTO.getCreateBy());
        int result = confirmedMenuMapper.insert(confirmedMenuDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public PageResult<DailyOrderDO> getTodayOrders(OrderDateQuery orderDateQuery) {
        Date orderDate = orderDateQuery.getOrderDate();
        List<DailyOrderDO> dailyOrderDOList = dailyOrderMapper.selectByOrderDate(orderDate);

        if (dailyOrderDOList != null) {
            // 设置分页参数（假设查询的是第一页，每页显示所有记录）
            long totalRecords = dailyOrderDOList.size();
            long totalPages = 1; // 只有一页
            long pageIndex = 1; // 当前页码
            long pageSize = totalRecords; // 每页显示所有记录

            PageResult<DailyOrderDO> pageResult = new PageResult<>(totalRecords, totalPages, pageIndex, pageSize, dailyOrderDOList);
            return pageResult;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public PageResult<ConfirmedMenuDO> getConfirmedMenus(ConfirmationDateQuery confirmationDateQuery) {
        Date confirmationDate = confirmationDateQuery.getConfirmationDate();
        List<ConfirmedMenuDO> confirmedMenuDOList = confirmedMenuMapper.selectByConfirmationDate(confirmationDate);

        if (confirmedMenuDOList != null) {
            // 设置分页参数（假设查询的是第一页，每页显示所有记录）
            long totalRecords = confirmedMenuDOList.size();
            long totalPages = 1; // 只有一页
            long pageIndex = 1; // 当前页码
            long pageSize = totalRecords; // 每页显示所有记录

            PageResult<ConfirmedMenuDO> pageResult = new PageResult<>(totalRecords, totalPages, pageIndex, pageSize, confirmedMenuDOList);
            return pageResult;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }
}
