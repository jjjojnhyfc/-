package com.oo.service.impl;

import com.oo.dao.DishCategoryMapper;
import com.oo.pojo.domain.DishCategoryDO;
import com.oo.pojo.dto.DishCategoryDTO;
import com.oo.pojo.query.DishCategoryQuery;
import com.oo.service.DishCategoryService;
import java.lang.Boolean;
import java.lang.Override;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo.exception.BusinessException;
import java.util.Map;
import com.oo.constant.ResultCodeConstant;

/**
 * DishCategoryServiceImpl
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
@Service
public class DishCategoryServiceImpl implements DishCategoryService {

    @Autowired
    private DishCategoryMapper dishCategoryMapper;

    @Override
    public Boolean addDishCategory(DishCategoryDTO dishCategoryDTO) {
        DishCategoryDO dishCategoryDO = new DishCategoryDO();
        dishCategoryDO.setCategoryName(dishCategoryDTO.getCategoryName());
        dishCategoryDO.setCreateBy(dishCategoryDTO.getCreateBy());
        int result = dishCategoryMapper.insert(dishCategoryDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean updateDishCategory(DishCategoryDTO dishCategoryDTO) {
        DishCategoryDO dishCategoryDO = new DishCategoryDO();
        dishCategoryDO.setCategoryId(dishCategoryDTO.getCategoryId());
        dishCategoryDO.setCategoryName(dishCategoryDTO.getCategoryName());
        dishCategoryDO.setUpdateBy(dishCategoryDTO.getUpdateBy());
        int result = dishCategoryMapper.updateById(dishCategoryDO);
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public Boolean deleteDishCategory(DishCategoryQuery dishCategoryQuery) {
        int result = dishCategoryMapper.deleteById(dishCategoryQuery.getCategoryId());
        if (result > 0) {
            return true;
        }
        throw new BusinessException(ResultCodeConstant.CODE_000001, ResultCodeConstant.CODE_000001_MSG);
    }

    @Override
    public List<DishCategoryDO> listDishCategories() {
        List<DishCategoryDO> dishCategoryDOList = dishCategoryMapper.selectAll();
        return dishCategoryDOList;
    }
}
