package com.oo.service;

import com.oo.pojo.domain.DishDO;
import com.oo.pojo.dto.DishDTO;
import com.oo.pojo.query.DishQuery;
import com.oo.pojo.vo.PageResult;
import java.util.List;

public interface DishService {
    Boolean addDish(DishDTO dishDTO);

    Boolean updateDish(DishDTO dishDTO);

    Boolean deleteDish(DishDTO dishDTO);

    // 修改批量删除方法的定义，添加 dishIds 参数
    Boolean deleteBatchDishes(List<Long> dishIds);

    PageResult<DishDO> queryDishes(DishQuery dishQuery);
}