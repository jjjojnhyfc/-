package com.oo.service;

import com.oo.pojo.domain.IngredientDO;
import com.oo.pojo.domain.IngredientRequirementDO;
import com.oo.pojo.dto.IngredientRequirementDTO;
import com.oo.pojo.query.IngredientRequirementQuery;
import java.lang.Boolean;
import java.lang.Object;
import java.util.List;

/**
 * 食材需求分析
 *
 * @author oo
 * @date 2025-02-22 12:08:45
 */
public interface IngredientRequirementService {

    /**
     * 获取食材需求
     *
     * @param ingredientRequirementQuery 食材需求查询条件
     * @return
     */
    List<IngredientRequirementDO> getIngredientRequirements(IngredientRequirementQuery ingredientRequirementQuery);

    /**
     * 列出已有食材
     *
     * @return
     */
    List<IngredientDO> listIngredients();

    /**
     * 更新食材需求
     *
     * @param ingredientRequirementDTO 食材需求信息
     * @return
     */
    Boolean updateIngredientRequirement(IngredientRequirementDTO ingredientRequirementDTO);

    /**
     * 新增食材需求
     *
     * @param ingredientRequirementDTO 食材需求信息
     * @return
     */
    Boolean addIngredientRequirement(IngredientRequirementDTO ingredientRequirementDTO);

    /**
     * 删除食材需求
     *
     * @param requirementId
     * @return
     */
    Boolean deleteIngredientRequirement(Object requirementId);
}
