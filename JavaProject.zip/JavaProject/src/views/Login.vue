<template>
  <el-form :model="form" label-width="80px" @submit.prevent="login">
    <el-form-item label="用户名">
      <el-input v-model="form.username" />
    </el-form-item>
    <el-form-item label="密码">
      <el-input v-model="form.password" type="password" />
    </el-form-item>
    <el-form-item label="验证码">
      <el-input v-model="form.verificationCode" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" native-type="submit">登录</el-button>
    </el-form-item>
  </el-form>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { loginApi } from '@/api/user'

const router = useRouter()
const form = ref({
  username: '',
  password: '',
  verificationCode: ''
})

const login = async () => {
  try {
    const res = await loginApi(form.value)
    if (res.code === '000000') {
      ElMessage.success('登录成功')
      router.push('/')
    }
  } catch (error) {
    ElMessage.error(error.message)
  }
}
</script> 