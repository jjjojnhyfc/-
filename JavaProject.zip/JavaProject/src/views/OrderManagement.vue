<template>
  <div>
    <el-button type="primary" @click="handleAdd">新增点单</el-button>
    <el-table :data="orders" style="width: 100%">
      <el-table-column prop="orderId" label="订单ID" />
      <el-table-column prop="userId" label="用户ID" />
      <el-table-column prop="dishId" label="菜品ID" />
      <el-table-column prop="quantity" label="数量" />
      <el-table-column prop="orderDate" label="点单日期" />
      <el-table-column label="操作">
        <template #default="scope">
          <el-button size="small" @click="handleConfirm(scope.row)">确认</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="dialogVisible" title="新增点单">
      <el-form :model="form" label-width="120px">
        <el-form-item label="用户ID">
          <el-input v-model="form.userId" />
        </el-form-item>
        <el-form-item label="菜品ID">
          <el-input v-model="form.dishId" />
        </el-form-item>
        <el-form-item label="数量">
          <el-input v-model="form.quantity" />
        </el-form-item>
        <el-form-item label="点单日期">
          <el-date-picker v-model="form.orderDate" type="date" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">提交</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { 
  getTodayOrdersApi, 
  addDailyOrderApi, 
  confirmMenuApi 
} from '@/api/order'

const orders = ref([])
const dialogVisible = ref(false)
const form = ref({
  userId: null,
  dishId: null,
  quantity: 1,
  orderDate: new Date()
})

onMounted(async () => {
  await fetchOrders()
})

const fetchOrders = async () => {
  const res = await getTodayOrdersApi({ orderDate: new Date() })
  orders.value = res.data.records
}

const handleAdd = () => {
  form.value = { userId: null, dishId: null, quantity: 1, orderDate: new Date() }
  dialogVisible.value = true
}

const handleConfirm = async (row) => {
  try {
    await confirmMenuApi({
      dishId: row.dishId,
      confirmationDate: new Date(),
      createBy: 1 // 假设当前用户ID为1
    })
    ElMessage.success('确认成功')
    await fetchOrders()
  } catch (error) {
    ElMessage.error(error.message)
  }
}

const submitForm = async () => {
  try {
    await addDailyOrderApi(form.value)
    ElMessage.success('点单成功')
    dialogVisible.value = false
    await fetchOrders()
  } catch (error) {
    ElMessage.error(error.message)
  }
}
</script>
