<template>
  <div>
    <el-button type="primary" @click="handleAdd">新增分类</el-button>
    <el-table :data="categories" style="width: 100%">
      <el-table-column prop="categoryId" label="ID" />
      <el-table-column prop="categoryName" label="分类名称" />
      <el-table-column label="操作">
        <template #default="scope">
          <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="dialogVisible" :title="dialogTitle">
      <el-form :model="form" label-width="120px">
        <el-form-item label="分类名称">
          <el-input v-model="form.categoryName" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">提交</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  getCategoriesApi, 
  addCategoryApi, 
  updateCategoryApi, 
  deleteCategoryApi 
} from '@/api/dishCategory'

const categories = ref([])
const dialogVisible = ref(false)
const dialogTitle = ref('')
const form = ref({
  categoryId: null,
  categoryName: '',
  createBy: 1,
  updateBy: 1
})

onMounted(async () => {
  await fetchCategories()
})

const fetchCategories = async () => {
  const res = await getCategoriesApi()
  categories.value = res.data
}

const handleAdd = () => {
  form.value = { categoryName: '', createBy: 1 }
  dialogTitle.value = '新增分类'
  dialogVisible.value = true
}

const handleEdit = (row) => {
  form.value = { ...row, updateBy: 1 }
  dialogTitle.value = '编辑分类'
  dialogVisible.value = true
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定删除该分类吗？', '提示', { type: 'warning' })
    await deleteCategoryApi({ categoryId: row.categoryId })
    ElMessage.success('删除成功')
    await fetchCategories()
  } catch (error) {
    console.log(error)
  }
}

const submitForm = async () => {
  try {
    if (form.value.categoryId) {
      await updateCategoryApi(form.value)
    } else {
      await addCategoryApi(form.value)
    }
    ElMessage.success('操作成功')
    dialogVisible.value = false
    await fetchCategories()
  } catch (error) {
    ElMessage.error(error.message)
  }
}
</script> 