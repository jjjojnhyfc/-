<template>
  <div>
    <el-button type="primary" @click="handleAdd">新增菜品</el-button>
    <el-table :data="dishes" style="width: 100%">
      <el-table-column prop="dishId" label="ID" />
      <el-table-column prop="dishName" label="菜品名称" />
      <el-table-column prop="categoryId" label="分类ID" />
      <el-table-column prop="price" label="价格" />
      <el-table-column label="操作">
        <template #default="scope">
          <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="dialogVisible" :title="dialogTitle">
      <el-form :model="form" label-width="120px">
        <el-form-item label="菜品名称">
          <el-input v-model="form.dishName" />
        </el-form-item>
        <el-form-item label="分类ID">
          <el-input v-model="form.categoryId" />
        </el-form-item>
        <el-form-item label="价格">
          <el-input v-model="form.price" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">提交</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  getDishesApi, 
  addDishApi, 
  updateDishApi, 
  deleteDishApi 
} from '@/api/dish'

const dishes = ref([])
const dialogVisible = ref(false)
const dialogTitle = ref('')
const form = ref({
  dishId: null,
  dishName: '',
  categoryId: null,
  price: 0,
  createBy: 1,
  updateBy: 1
})

onMounted(async () => {
  await fetchDishes()
})

const fetchDishes = async () => {
  const res = await getDishesApi()
  dishes.value = res.data
}

const handleAdd = () => {
  form.value = { dishName: '', categoryId: null, price: 0, createBy: 1 }
  dialogTitle.value = '新增菜品'
  dialogVisible.value = true
}

const handleEdit = (row) => {
  form.value = { ...row, updateBy: 1 }
  dialogTitle.value = '编辑菜品'
  dialogVisible.value = true
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定删除该菜品吗？', '提示', { type: 'warning' })
    await deleteDishApi({ dishId: row.dishId })
    ElMessage.success('删除成功')
    await fetchDishes()
  } catch (error) {
    console.log(error)
  }
}

const submitForm = async () => {
  try {
    if (form.value.dishId) {
      await updateDishApi(form.value)
    } else {
      await addDishApi(form.value)
    }
    ElMessage.success('操作成功')
    dialogVisible.value = false
    await fetchDishes()
  } catch (error) {
    ElMessage.error(error.message)
  }
}
</script> 